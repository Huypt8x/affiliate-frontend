import express from "express";

const router = express.Router();

const programs = [
  { id: 1, name: "Amazon Affiliate", commission: "10%", url: "https://amazon.com" },
  { id: 2, name: "Shopee Affiliate", commission: "8%", url: "https://shopee.vn" },
  { id: 3, name: "Lazada Affiliate", commission: "7%", url: "https://lazada.vn" }
];

router.get("/", (req, res) => {
  res.json(programs);
});

router.post("/track/:id", (req, res) => {
  const { id } = req.params;
  console.log(`🔥 Click tracked on program ${id}`);
  res.json({ message: `Click tracked on program ${id}` });
});

export default router;
