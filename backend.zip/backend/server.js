import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import programsRouter from "./routes/programs.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Affiliate Backend API Running 🚀");
});

app.use("/api/programs", programsRouter);

app.listen(PORT, () => {
  console.log(`✅ Backend running on http://localhost:${PORT}`);
});
