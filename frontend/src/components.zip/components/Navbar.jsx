import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import ThemeToggle from './ThemeToggle'
import LangSwitch from './LangSwitch'
import { useTranslation } from 'react-i18next'

export default function Navbar(){
  const { t } = useTranslation()
  return (
    <header className='w-full header-shadow bg-blue-600 dark:bg-slate-900 text-white'>
      <div className='max-w-6xl mx-auto flex items-center justify-between px-6 py-4'>
        <Link to='/' className='text-2xl font-bold'>Super Affiliate</Link>
        <nav className='flex items-center gap-6'>
          <NavLink to='/' className={({isActive})=> (isActive? 'underline':'')}>{t('Home')}</NavLink>
          <NavLink to='/affiliate' className={({isActive})=> (isActive? 'underline':'')}>{t('Affiliate')}</NavLink>
          <NavLink to='/pricing' className={({isActive})=> (isActive? 'underline':'')}>{t('Pricing')}</NavLink>
          <NavLink to='/theme' className={({isActive})=> (isActive? 'underline':'')}>{t('Theme')}</NavLink>
          <LangSwitch />
          <ThemeToggle />
          <button className='ml-2 bg-white text-blue-600 px-4 py-1 rounded-full font-medium'>{t('Sign In')}</button>
        </nav>
      </div>
    </header>
  )
}
