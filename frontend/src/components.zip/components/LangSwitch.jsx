import React from 'react'
import { useTranslation } from 'react-i18next'

export default function LangSwitch(){
  const { i18n } = useTranslation()
  return (
    <select 
      value={i18n.language} 
      onChange={(e)=>i18n.changeLanguage(e.target.value)}
      className='bg-white/20 px-2 py-1 rounded-full text-sm'
    >
      <option value='en'>EN</option>
      <option value='vi'>VI</option>
    </select>
  )
}
